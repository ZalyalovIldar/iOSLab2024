//
//  PhotosViewController.swift
//  HW_2
//
//  Created by Damir Rakhmatullin on 23.11.24.
//

import UIKit

class PhotosViewController: UIViewController {
    
    private lazy var button: UIButton = {
          let action = UIAction { [weak self] _ in
              self?.dismiss(animated: true)
          }

          let button = UIButton(configuration: .plain(), primaryAction: action)
          button.translatesAutoresizingMaskIntoConstraints = false
          return button
      }()
      
      private lazy var image: UIImageView = {
          let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
          image.clipsToBounds = true
          image.contentMode = .scaleAspectFill
          image.translatesAutoresizingMaskIntoConstraints = false
          return image
      }()
      
      init(photo: UIImage) {
          super.init(nibName: nil, bundle: nil)
          self.image.image = photo
      }
      
      required init?(coder: NSCoder) {
          fatalError("init(coder:) has not been implemented")
      }
      
      override func viewDidLoad() {
          super.viewDidLoad()
          layout()
      }
      
      private func layout() {
          view.addSubview(button)
          view.addSubview(image)

          NSLayoutConstraint.activate([
              button.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
              button.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
              button.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
              button.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),

              image.centerXAnchor.constraint(equalTo: button.centerXAnchor),
              image.centerYAnchor.constraint(equalTo: button.centerYAnchor),
              image.heightAnchor.constraint(equalToConstant: UIScreen.main.bounds.height / 2),
              image.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.width / 2)
          ])
      }
}
